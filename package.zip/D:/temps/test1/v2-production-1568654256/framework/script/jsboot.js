/**********************************************************************
 * (C) 2013 Wombat Security Technologies, Inc.
 * Description: A Javascript file that "bootstraps" other javascript files
 * Author: Jason R Brubaker
 * Date: 9/5/13
 **********************************************************************/
(function() {

	/**
	 * Keep track of library source roots
	 * @type {{}}
	 */
	var roots = {};

	/**
	 * Keep a global root path
	 * @type {string}
	 */
	var global_root = '';

	/**
	 * Boot one or more libraries
	 * @param {{file:String, root:String}[]|String[]} libraries - Minified javascript files containing a javascript library
	 * @param {String} [mode] - Either "prod" for production, or "test" for test environment
	 * @param {String} [root_path] - Optionally, specify a path that will serve as a universal root for all javascript loaded via jsboot
	 */
	var boot = function(libraries, mode, root_path) {

		// determine the mode being used
		var q_mode = getParam('bootmode');		// get mode from querystring
		if (q_mode && q_mode !==''){
			mode = q_mode;
		}

		// do we have a mode to save?
		if (mode) { window.jsbootmode = mode; }

		// should we save root_path to the global_root?
		if (root_path) { global_root = root_path; }

		// load the libraries
		for (var i = 0; i < libraries.length; i++) {
			// load the minified file - it will load sources if bootmode is not prod
			loadLibrary(libraries[i]);
		}
	};

	/**
	 * Load a library
	 * @param {{file:String, root:String}|String} library The library to load
	 */
	var loadLibrary = function loadLibrary(library) {
		var path, source;

		// get path, source path
		if (typeof library !== 'string') {
			path = library.file;
			source = library.root;
			if (source && source.lastIndexOf("/") !== source.length - 1) {
				source += "/";
			}
		} else {
			path = library;
		}

		// get filename
		var filename = path.substr(path.lastIndexOf("/") + 1);

		// if the filename ends in ".min.js", save the index
		var prefix_index = filename.indexOf(".min.js");

		// determine where to get the sources for the library
		if (source) {
			// source specified
			roots[filename] = global_root + source;
		} else if (prefix_index > -1) {
			// no source specified, but the '.min.js' indicates that it should be loaded from a directory of the same name
			roots[filename] = global_root + filename.substring(0, prefix_index) + "/";
		}

		// load the minified file
		loadFile(global_root + path);
	};

	/**
	 * Load the sources for a library
	 * @param {{file:String, src:Array}} library
	 */
	var loadLibrarySources = function loadLibrarySources(library) {
		// get root
		var root = roots[library.file];

		for (var i=0; i<library.src.length; i++) {
			loadFile(root + library.src[i]);
		}
	};

	/**
	 * Load a file
	 * @param {String} uri The uri of the file
	 */
	var loadFile = function loadFile(uri) {
		// create a DOM SCRIPT node
		var node = document.createElement('script');
		node.setAttribute('src', uri);
		node.setAttribute('type', 'text/javascript');

		// write to document to start loading...
		document.write(node.outerHTML);
	};

	/**
	 * Get a querystring parameter
	 * @param {String} name
	 * @returns {string}
	 */
	var getParam = function getParam(name) {
		name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
		var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
			results = regex.exec(location.search);
		return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	};

	/**
	 * Set the default jsbootmode
	 * @type {string}
	 */
	window.jsbootmode = 'prod';

	/**
	 * Boot one or more libraries
	 * @param {{file:String, root:String}[]} libraries Minified javascript files containing a javascript library
	 * @param {String} [mode] Either "prod" for production, or "test" for test environment
	 */
	window.jsboot = boot;

	/**
	 * Load the sources for a library
	 * @param {{file:String, src:Array}} library
	 */
	window.jsloadlib = loadLibrarySources;

})();