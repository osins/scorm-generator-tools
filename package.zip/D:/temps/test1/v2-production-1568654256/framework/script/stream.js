wombat.require( 'vendor.swp.Message' );
wombat.register( 'vendor.swp.Stream' );

/**
 * Each Stream class instance is an isolated stream of Messages wrapping the ajax requests
 */

vendor.swp.Stream = (function () {
	// Do some setup
	function Stream( id, jQuery, options ) {
		if ( options === void 0 ) {
			options = {};
		}
		// state object
		this.state = {
			n: 0,
			n_t: -1,
			n_a: -1,
			cache: [],
			n_o: 0 // an offset, in case message sequence numbers don't start at 0
		};
		// how many consecutive errors have we received?
		this.error_count = 0;
		// what time was the last error received?
		this.error_time = new Date( 0 );
		this.alert_time = 0;
		this.alert_status = 0;
		// extend default options
		options = jQuery.extend( true, {
			last_ack: 0,
			sequence_property_path: 'sequence',
			acknowledge_property_path: 'ack',
			window_size: 3,
			request_timeout: 30,
			error_timeout: 2
		}, options );
		// save the initialization parameters
		this.$ = jQuery;
		this.id = id;
		this.sequence_property_path = options.sequence_property_path;
		this.acknowledge_property_path = options.acknowledge_property_path;
		this.window_size = options.window_size;
		this.request_timeout = options.request_timeout;
		this.error_timeout = options.error_timeout;
		this.max_error_timeout = Math.pow( this.error_timeout, 6 );
		this.save_before_unload = !!options.save_before_unload;
		this.dataModifier = options.dataModifier;
		// save ajax options
		this.ajax_settings = options.ajax_settings || {};
		this.callbacks = jQuery.extend( {}, options.request_callbacks );
		// retrieve state/cache from storage
		this.retrieveFromStorage( options.last_ack );
		// keep a bound version of the saveToStorage method
		this.boundSave = this.saveToStorage.bind( this );
	}

	// Start the stream
	Stream.prototype.start = function ( interval ) {
		if ( interval === void 0 ) {
			interval = 250;
		}
		// set the start time
		this.start_time = new Date();
		this.timer = window.setInterval( this.tick.bind( this ), interval );
		if ( this.save_before_unload ) {
			window.addEventListener( 'beforeunload', this.boundSave );
		}
	};
	// Stop streaming messages
	Stream.prototype.stop = function () {
		window.clearInterval( this.timer );
		if ( this.save_before_unload ) {
			window.removeEventListener( 'beforeunload', this.boundSave );
		}
	};
	// Create a new request and put it in the cache. The next timer event will send it if possible.
	Stream.prototype.newRequest = function ( url, payload ) {
		this.state.cache.push( new vendor.swp.Message( this.state.n++, url, payload, this.sequence_property_path, this.dataModifier ) );
		this.saveToStorage();
	};
	// Alias for "newRequest"
	Stream.prototype.push = function ( url, payload ) {
		this.newRequest( url, payload );
	};
	// Get stats about the health of the stream
	Stream.prototype.getHealthStats = function () {
		var _this = this;
		return {
			consecutive_errors: this.error_count,
			unacked_messages: this.state.cache.reduce( function ( memo, message ) {
				if ( message.status !== 'acknowledged' && message.sent > _this.start_time ) {
					memo++;
				}
				return memo;
			}, 0 ),
			current_error_timeout: this.currentErrorTimeout()
		};
	};
	// Register to receive alerts about network health
	Stream.prototype.registerForHealthAlerts = function ( interval, tests, callback ) {
		this.alert_interval = interval;
		this.alert_tests = tests;
		this.alert_callback = callback;
	};
	/**
	 * A public way to reset the error time (useful if we want to retry to connect immediately)
	 */
	Stream.prototype.resetErrorTime = function () {
		this.error_time = new Date( 0 );
	};
	/**
	 * A public way to reset the error count and time
	 */
	Stream.prototype.resetErrors = function () {
		this.error_count = 0;
		this.resetErrorTime();
	};
	/**
	 * A public way to add a new error to the error count
	 */
	Stream.prototype.addError = function () {
		this.error_time = new Date();
		this.error_count++;
	};
	// Get the current error timeout (based on current number of consecutive errors)
	Stream.prototype.currentErrorTimeout = function () {
		return Math.min( this.max_error_timeout, Math.pow( this.error_timeout, this.error_count ) );
	};
	// Handles the interval tick to send messages.
	Stream.prototype.tick = function () {
		// Make sure we aren't within the error timeout
		if ( !this.inErrorTimeout() ) {
			// Send the first message we find that is in "error" or "cache" status. Once one is found, send
			// it and break so we don't go any further
			var i = void 0, window_min = this.state.n_a + 1, window_max = this.state.n_a + this.window_size;
			for ( i = window_min; i <= Math.min( window_max, this.state.cache.length - 1 + this.state.n_o ); i++ ) {
				var message = this.getMessage( i );
				if ( message.needsToBeSent() ) {
					this.sendMessage( message );
					break;
				}
			}
		}
		// Check for alerts
		this.doAlerts();
	};
	// Send a message
	Stream.prototype.sendMessage = function ( message ) {
		var _this = this;
		this.updateN_T( message.n );
		// create request
		var request = message.send( this.$, this.request_timeout, this.ajax_settings );
		// add callbacks for stream
		request.done( function ( data ) {
			// reset error count & time
			_this.resetErrors();
			// record acknowledgment from server
			_this.updateN_A( _this.extractAcknowledgeNumber( data ) );
		} )
			.fail( function ( jqXHR, textStatus ) {
				// record error time & increment count
				if ( textStatus !== 'timeout' ) {
					_this.addError();
				}
			} );
		// add custom callbacks
		if ( this.callbacks.done ) {
			request.done( this.callbacks.done );
		}
		if ( this.callbacks.fail ) {
			request.fail( this.callbacks.fail );
		}
		if ( this.callbacks.always ) {
			request.always( this.callbacks.always );
		}
	};
	// Do alert tests and call callback if necessary
	Stream.prototype.doAlerts = function () {
		if ( this.alert_tests ) {
			var now = (new Date()).valueOf(), tests = this.alert_tests, stats = this.getHealthStats(), i = void 0;
			// make sure enough time has elapsed
			if ( this.alert_time && this.alert_time + this.alert_interval > now ) {
				return;
			}
			// save new alert_time if we're still here
			this.alert_time = now;
			// iterate backwards through the health tests
			for ( i = tests.length - 1; i > -1; i-- ) {
				// new status will either be
				//  a) 0 (if no tests match)
				//  b) the first status check to return true
				//  b) one less than the current status
				if ( i == 0 || Stream.hasAlertStatus( stats, tests[i] ) || i == this.alert_status - 1 ) {
					break;
				}
			}
			// trigger events when status changes
			if ( this.alert_status !== i ) {
				// call the alert callback regarding leaving the previous status
				this.alert_callback( 'leave:status', tests[this.alert_status].status );
				// update the status
				this.alert_status = i;
				// call the alert callback regarding entering the new status
				this.alert_callback( 'enter:status', tests[this.alert_status].status );
			}
		}
	};
	// Does the current health status fall within the bounds of the test?
	Stream.hasAlertStatus = function ( stats, test ) {
		var result = false, property;
		for ( property in test ) {
			if ( test.hasOwnProperty( property ) && stats.hasOwnProperty( property ) ) {
				result = result || (stats[property] >= test[property]);
			}
		}
		return result;
	};
	// Save to local storage
	Stream.prototype.saveToStorage = function () {
		try {
			localStorage.setItem( this.storageId(), JSON.stringify( this.state ) );
		}
		catch ( e ) {
			console.error( e );
		}
	};
	// Retrieve from local storage
	Stream.prototype.retrieveFromStorage = function ( last_ack ) {
		var state;
		try {
			state = localStorage.getItem( this.storageId() );
		}
		catch ( e ) {
			console.error( e );
		}
		if ( state ) {
			this.state = JSON.parse( state );
			// turn saved message data into message objects
			for ( var i = 0; i < this.state.cache.length; i++ ) {
				var status = this.state.cache[i].status;
				this.state.cache[i].status = status === "transmitted" ? "cached" : status;
				this.state.cache[i] = vendor.swp.Message.fromJSON( this.state.cache[i], { dataModifier: this.dataModifier } );
			}
		}
		else if ( last_ack ) {
			// n_a, n_t should equal passed-in last_ack
			this.state.n_a = this.state.n_t = last_ack;
			// n_o is an offset to point the sequence number at the index
			this.state.n_o = last_ack + 1;
			// sequence number (next message gets this number) should be equal to the offset
			this.state.n = this.state.n_o;
		}
	};
	// Build an ID for local storage
	Stream.prototype.storageId = function () {
		return 'ajax-sliding-window.' + this.id;
	};
	// Update our n_t to the most recent value
	Stream.prototype.updateN_T = function ( n_t ) {
		this.state.n_t = Math.max( this.state.n_t, n_t );
		this.saveToStorage();
	};
	// Update our n_a to the most recent value, updating the message statuses as we go
	Stream.prototype.updateN_A = function ( n_a ) {
		var i, old_n_a = this.state.n_a;
		// update n_a
		this.state.n_a = Math.max( this.state.n_a, n_a );
		// update any messages between old & new n_a (inclusive)
		for ( i = old_n_a + 1; i <= this.state.n_a; i++ ) {
			var message = this.getMessage( i );
			message.status = 'acknowledged';
		}
		// save
		this.saveToStorage();
	};
	/**
	 * Get the message by sequence number (uses offset if necessary)
	 */
	Stream.prototype.getMessage = function ( sequence_number ) {
		return this.state.cache[sequence_number - this.state.n_o];
	};
	// Has an error been received too recently for us to send another message?
	Stream.prototype.inErrorTimeout = function () {
		if ( !this.error_count ) {
			return false;
		}
		else {
			return this.error_time.valueOf() + this.currentErrorTimeout() * 1000 > (new Date()).valueOf();
		}
	};
	/**
	 * Extract the acknowledged sequence number from the data
	 */
	Stream.prototype.extractAcknowledgeNumber = function ( data ) {
		var node = data, path = this.acknowledge_property_path.split( '.' ), n_a;
		for ( var i = 0; i < path.length; i++ ) {
			if ( i < path.length - 1 ) {
				node = node[path[i]];
				if ( !(node && node instanceof Object) ) {
					break;
				}
			}
			else {
				n_a = node[path[i]];
			}
		}
		return n_a;
	};
	return Stream;
}());