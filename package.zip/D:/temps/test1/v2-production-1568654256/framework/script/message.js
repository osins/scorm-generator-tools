wombat.register( 'vendor.swp.Message' );

/**
 * Each message sent gets wrapped in an instance of this class to keep track of meta data
 */
vendor.swp.Message = (function() {
	function Message( n, url, payload, path, dataModifier ) {
		this.status = 'cached';
		this.error = null;
		this.n = n;
		this.url = url;
		this.payload = payload;
		if( path ) {
			this.insertSequenceNumber( path );
		}
		this.setDataModifier( dataModifier );
	}

	/**
	 * Send the message
	 */
	Message.prototype.send = function( $, timeout, ajax_options ) {
		var _this = this;
		this.request = $.ajax( this.url, $.extend( {
			type: 'POST',
			contentType: 'json',
			data: this.dataModifier ? this.dataModifier( this.payload ) : this.payload,
			timeout: timeout * 1000
		}, ajax_options ) );
		// handle response to update status & error properties
		this.request
			.done( function() {
				if( _this.status == 'transmitted' ) {
					_this.status = 'received';
				}
				_this.received = new Date();
				_this.error = null;
			} )
			.fail( function( jqXHR, textStatus, errorThrown ) {
				if( _this.status == 'transmitted' ) {
					_this.status = 'error';
				}
				_this.error = errorThrown;
			} );
		// set status to 'transmitted' while it's being sent
		this.status = 'transmitted';
		this.sent = new Date();
		// return request for further processing
		return this.request;
	};
	// Does this message need to be sent?
	Message.prototype.needsToBeSent = function() {
		return this.status == 'cached' || this.status == 'error';
	};
	// Extract data for saving in JSON format
	Message.prototype.toJSON = function() {
		var json = {
			n: this.n,
			url: this.url,
			payload: this.payload,
			status: this.status
		};
		if( this.sent ) {
			json[ 'sent' ] = this.sent.valueOf();
		}
		if( this.received ) {
			json[ 'received' ] = this.received.valueOf();
		}
		return json;
	};
	// Generate a message object from data parsed from JSON data
	Message.fromJSON = function( data, options ) {
		var m = new Message();
		m.n = data.n;
		m.url = data.url;
		m.payload = data.payload;
		m.status = data.status;
		if( data.sent ) {
			m.sent = new Date( data.sent );
		}
		if( data.received ) {
			m.received = new Date( data.received );
		}
		// set the dataModifier to what was passed in
		if( options && options.dataModifier ) {
			m.setDataModifier( options.dataModifier );
		}
		return m;
	};
	/**
	 * Insert a sequence number into the payload
	 */
	Message.prototype.insertSequenceNumber = function( path ) {
		var node = this.payload, path = path.split( '.' );
		for( var i = 0; i < path.length; i++ ) {
			if( i < path.length - 1 ) {
				node = node[ path[ i ] ];
				if( !(node && node instanceof Object) ) {
					break;
				}
			}
			else {
				node[ path[ i ] ] = this.n;
			}
		}
	};
	/**
	 * Set the dataModifier function so we can manipulate the payload when sending a Message
	 */
	Message.prototype.setDataModifier = function( modifier ) {
		if( modifier ) {
			this.dataModifier = modifier;
		}
	};
	return Message;
}());