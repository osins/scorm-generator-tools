/**********************************************************************
 * (C) 2012 Wombat Security Technologies, Inc.
 * wombat.ict.plugins.ModuleSummary Class Definition
 * Description: Shows a summary of the module's assessments
 * Author: Jason R Brubaker
 *          - converted by JRB on 2/20/2014
 * Date: 10/22/12
 **********************************************************************/

/**
 * Show a module summary
 * @param {Object} options Summary options
 * @param {wombat.ict.ContainerInterface} options.container The module's main content container
 * @param {wombat.ict.ContainerController} options.controller Controller for the module's main content container
 * @param {wombat.ict.LessonState[]} options.lesson_states Each lesson's state
 * @param {Object} options.instruct Standard Instruct options object
 * @param {String} options.button The name of the button to hijack from options.controller
 * @param {Object} [options.selectors] Collection of selectors used in rendering the summary
 * @param {String} [options.type=itemized] The type of summary to show. Default is "itemized" (shows every item in each assessment)
 * @param {String} [options.lesson_text_tag=lesson] The text tag to use before the lesson ID.
 * @constructor
 * @extends wombat.ict.plugins.Base
 */
wombat.ict.plugins.ModuleSummary = function ModuleSummary(options) {

	/**
	 * Initialize plugins.Base; returns 'this' alias
	 * @type {wombat.ict.plugins.ModuleSummary}
	 */
	var This = this.__init__();

	// alias types
	var TYPES = wombat.ict.plugins.ModuleSummary.TYPES;

	// extend base settings w/ plugin defaults & options param
	this._settings = $.extend(true, This._settings, {
		type: TYPES.STANDARD,
		lesson_text_tag: 'status_designations.lesson',
		correct_tag: 'summary.correct',
		selectors: {
			scores: '.ict-summary-scores'
		}
	}, options);

	/**
	 * The instruct that holds the summary layout
	 * @type {wombat.ict.Instruct}
	 */
	this.instruct;

	/**
	 * Constructor
	 * @private
	 */
	function _init_() {
		This.createInstruct();
	}

	/* Public methods **************************************************/

	/**
	 * Create an instruct with the supplied layout information
	 */
	this.createInstruct = function createInstruct() {
		// create an instruct for the summary screen
		this.instruct = new wombat.ict.Instruct(This._settings.instruct, null,
			new wombat.Callback({ c:This, f:this.renderLayout })
		);
	};

	/**
	 * Render the layout & add it to the screen
	 */
	this.renderLayout = function renderLayout() {
		// render the HTML of the layout into an element
		this.instruct.render();

		// update the main content container with the instruct's element
		This._settings.container.update(
			this.instruct.instruct_element,
			{type:wombat.ict.ContainerInterface.TRANSITIONS.FADE},
			new wombat.Callback({c:This, f:this.handleLayoutShown}),
			new wombat.Callback({c:This, f:this.handleLayoutAdded})
		);
	};

	/**
	 * The layout has been added to the DOM, so it's time to set up the interface
	 */
	this.handleLayoutAdded = function handleLayoutAdded() {
		// definitions
		var $box, $div;
		var span_html = "<span class='td'></span>";

		// truncate the controller button stacks
		This._settings.controller.truncateButtonStacks(null, true);

		// render the feedback
		$box = $(This._settings.selectors.scores);
		$.each(This._settings.lesson_states, function(index, lesson_state){
			// get the score
			var score = lesson_state.getCombinedScore();

			// only show the lesson if it has at least one interaction
			if (score.total > 0) {
				// create div
				$div = $("<div class='tr'></div>");

				// create first span: lesson designation ("Lesson 1", etc)
				$(span_html)
					.addClass("td green bold")
					.text(wombat.assets.getText(This._settings.lesson_text_tag).replace('|:id:|', lesson_state.id) + ' - ').
					appendTo($div);

				// create second span: lesson title
				$(span_html)
					.addClass("italic")
					.css({"font-weight": "normal", "font-size": "22px", "line-height": "24px", "width": "560px", "vertical-align": "top", "display": "inline-block"})
					.append(wombat.assets.getText("lesson_titles."+lesson_state.id))
					.appendTo($div);

				// create third span: score
				$(span_html)
					.addClass("right bold")
					.append(score.correct + "/" + score.total + " " + wombat.assets.getText(This._settings.correct_tag))
					.appendTo($div);

				// append div to box
				$box.append($div);
			}
		});
	};

	/**
	 * The layout has been shown - wire & show buttons, etc.
	 */
	this.handleLayoutShown = function handleLayoutShown() {
		// make sure the summary page buttons are ready/enabled (in case clicking happened between lessons)
		This._settings.controller.handled();

		// standard module summaries hijack a controller button
		This._settings.controller.hijackButton(This._settings.button.name, {
			callback: new wombat.Callback({
				c: this,
				f: this.handleButtonClick,
				allow_multiple: true
			}),
			tag: This._settings.button.exit_tag
		}, true);

		// hide or show button based on visibility
		if (This._settings.button.visibility === "HIDDEN") {
			This._settings.controller.delayHide( This._settings.button.name );
		}

		// update controller button visibilities
		This._settings.controller.updateButtons();

		// update help system
		LearningModule.helpUpdate(this.instruct.instruct_element);
	};

	/**
	 * Handle a button click
	 */
	this.handleButtonClick = function handleButtonClick() {
		// tell controller we've handled the button click
		This._settings.controller.handled();

		// create callback
		var cb = new wombat.Callback( {
			c:This,
			f: function(okay){
				if (okay) {
					// complete instruct so it's not sitting out there
					This.instruct.complete();

					// release & hide the controller button right away
					This._settings.controller.releaseButton(This._settings.button.name);
					This._settings.controller.hideButton(This._settings.button.name, null, true);
				}
			}
		});

		// we came from the end of a lesson, so we are "exit"ing
		cb.call();
		LearningModule.exit();
	};

	// initialize
	_init_();
};

/** Extend from plugins.Base **/
wombat.extensible.extend(wombat.ict.plugins.Base, wombat.ict.plugins.ModuleSummary);

/** Module Summary types @type {Object} */
wombat.ict.plugins.ModuleSummary.TYPES = {
	STANDARD: 'standard',
	CLASSIC: 'classic'
};

/** Configure assets **/
wombat.ict.plugins.ModuleSummary.ASSETS = { };

