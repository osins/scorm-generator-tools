/********************************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description:	Root directory for url plugin
 * Author:		Jason R Brubaker
 * Date:        8/4/2014
 *******************************************************************************/

wombat.register('wombat.ict.plugins.url');

/**
 * Define namespace for url plugin
 * @namespace wombat.ict.plugins.url
 */
wombat.ict.plugins.url = {};

/**
 * Define assets for the plugin
 */
wombat.ict.plugins.url.ASSETS = {
	"templates": "<:path tag='ict.plugins' :>/url/url.html"
};

/********************************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description: The class for each URL element in a URL PluginRound
 * Author:		Chris A Vaccarello, Jason R. Brubaker
 * Date:        4/9/14
 *******************************************************************************/

wombat.require('wombat.ict.plugins.url');
wombat.register('wombat.ict.plugins.url.DecisionPoint');

/**
 * Each round shows a bunch of URLs for the user to make a decision on. The DecisionPoint class does the work for that
 * @param {number} id The index of the DecisionPoint
 * @param {wombat.ict.assess.RoundState} state - RoundState object from the parent Round
 * @param {wombat.ict.assess.Question} question - Question associated with this URL choice
 * @param {object} settings - Settings for the DecisionPoint
 * @memberOf wombat.ict.plugins.url
 * @mixes wombat.events.Mixin
 * @constructor
 */
wombat.ict.plugins.url.DecisionPoint = function DecisionPoint(id, state, question, settings) {
	// alias
	var This = this;

	settings = $.extend(true, {
		elements: {
			page: null,
			container: null
		},
		selectors: {
			decision_box: '.url-bar'
		},
		templates: {
			url_box: "html.templates.url-box",
			decision_box: "html.templates.decision-box",
			feedback_message: "url.html.message"
		},
		decision_box: {
			delay_hide: 1000,
			offset: {
				left: 0,
				top: 0
			}
		}
	}, settings);

	/*****************************************************************************************************************
	 *  PUBLIC VARIABLES
	 *****************************************************************************************************************/
	this.id = id;
	this.question = question;
	this.state = state;
	this.$element = null;
	this.$decision_box = null;
	this.feedback_html = null;

	this.x = 0;
	this.y = 0;
	this.dimensions = {
		width: null,
		height: null,
		margin: {
			top: null,
			right: null,
			bottom: null,
			left: null
		}
	};

	/*****************************************************************************************************************
	 *  PRIVATE VARIABLES
	 *****************************************************************************************************************/

	// shortcuts
	var $page = settings.elements.page;
	var $container = settings.elements.container;

	// counter to show teaching
	var teaching_message = 0;

	/*****************************************************************************************************************
	 *  _INIT_
	 *****************************************************************************************************************/
	function _init_() {
		// register some events
		This._registerEvents();
	}

	/*****************************************************************************************************************
	 *  PUBLIC METHODS
	 *****************************************************************************************************************/
	/**
	 * Make this URL Box/Element interactive (turn on mouseover and mouseleave)
	 */
	this.activate = function activate() {
		This.$element.mouseenter(This.select);
		This.$element.mouseleave(This.deselect);
	};

	this.select = function select(e) {
		// remove all decision boxes except the current one
		$(settings.selectors.decision_box).not(This.$decision_box).remove();

		// start the URL hover effect
		urlHover(e);
	};

	this.deselect = function select(e) {
		urlLeave(e);
	};

	/**
	 * Make this URL Box/Element non-interactive (turn off events)
	 */
	this.deactivate = function deactivate() {
		This.$element.off('mouseenter')
			.off('mouseleave');
	};

	/**
	 * position the url element on the page
	 * @param pos_x
	 * @param pos_y
	 */
	this.positionBox = function positionBox(pos_x, pos_y) {
		This.x = pos_x; This.y = pos_y;

		This.$element.css({
			"position": "absolute",
			"left": This.x+"px",
			"top": This.y+"px"
		});
	};

	/**
	 * User has visited url (also known as Eat)
	 * @returns {{points: number, lives: number, time: number}}
	 */
	this.decisionVisit = function decisionVisit() {
		return handleDecision("visit");
	};

	/**
	 * User has avoided url (also known as Reject)
	 * @returns {{points: number, lives: number, time: number}}
	 */
	this.decisionAvoid = function decisionAvoid() {
		return handleDecision("avoid");
	};

	/**
	 * User wants "teach" help for URL
	 */
	this.decisionTeach = function decisionTeach() {
		handleTeach();
	};

	/**
	 * Cancel the decision
	 */
	this.decisionCancel = function decisionCancel() {
		This.$decision_box.remove();        // remove the element
		This._fire(This.EVENT.URL_ACTIVE, null);     // deactivate
	};

	/**
	 * Get a message for this DecisionPoint
	 * @param message
	 * @returns {String}
	 */
	this.getMessage = function getMessage(message) {
		return renderMessage(question, message)
	};

	/*****************************************************************************************************************
	 *  PROTECTED METHODS
	 *****************************************************************************************************************/

	/**
	 * Create this.$element, this.$decision_box, and get associated dimensions
	 * @protected
	 */
	this._createElements = function _createElements() {
		// create box template/element
		This.$element = wombat.assets.getAsset(settings.templates.url_box, {dom: true});

		// create a decision_box element to display relevant information for this url
		This.$decision_box = wombat.assets.getAsset(settings.templates.decision_box, {
			dom: true, replace: {
				url: question.config.uri
			}
		});

		// add element to $container
		This.$element.appendTo($container);

		// figure out dimensions
		This.dimensions = {
			width: This.$element.outerWidth(),
			height: This.$element.outerHeight(),
			margin: {
				top: parseInt(This.$element.css("margin-top")),
				right: parseInt(This.$element.css("margin-right")),
				bottom: parseInt(This.$element.css("margin-bottom")),
				left: parseInt(This.$element.css("margin-left"))
			}
		};

		This.$element.attr("data-index", id);
		This.$element.attr("id", "url-"+id);      // for selenium testing
	};

	/**
	 * Override to calculate where the decision box should go
	 * @param e - the event object that triggered the call
	 * @returns {StandardPosition}
	 * @protected
	 */
	this._calculateDecisionPosition = function calculateDecisionPosition(e) { return new StandardPosition(e.pageY, e.pageX); };


	/*****************************************************************************************************************
	 *  PRIVATE FUNCTIONS
	 *****************************************************************************************************************/
	/**
	 *  handle teaching messages
	 */
	var handleTeach = function handleTeach() {
		var html = createTeachMessage(question);

		// show teaching feedback
		This._fire(This.EVENT.SHOW_MESSAGE, html, true);
	};

	/**
	 * Handle the decision event
	 * @param {string} response String representing the decision
	 * @returns {{points: number, lives: number, time: number}}
	 */
	var handleDecision = function handleDecision(response) {
		// complete the question
		question.complete(response);

		// deactivate current DecisionPoint box so it can't be answered again
		This._fire(This.EVENT.URL_ACTIVE, null);

		// create feedback and html for feedback (and store for use later)
		This.feedback_html = createFeedbackMessage(question);

		// show feedback
		This._fire(This.EVENT.SHOW_MESSAGE, This.feedback_html);

		// pass the correct statusEvent into the RoundState
		var changes = This.state.statusEvent(question.response, question.getCorrectString());

		// let the Round know that this URL has been completed
		This._fire(This.EVENT.URL_COMPLETE, This.id);

		// return changes
		return changes;
	};

	/**
	 * create the html
	 * @param {wombat.ict.assess.Question} q The question for which to render the message
	 * @returns {string} html template
	 */
	var createTeachMessage = function createTeachMessage(q) {
		// select a random teach option from the list of options for this url's category
		var teach_options = wombat.assets.getText('game.categories.' + q.config.category.after('.') + '.teach');

		// display teaching randomly or in order
		var teach = "";
		var length = wombat.utility.objLength(teach_options) - 1;
		if (wombat.ict.global_settings.no_randomness) {
			if (teaching_message > length) teaching_message = 0;
			teach = teach_options[teaching_message];
			teaching_message++;
		} else {
			teach = teach_options[Math.randomInt(length)];
		}

		return renderMessage(q, teach);
	};

	/**
	 * create the html
	 * @param {wombat.ict.assess.Question} q The question for which to render the message
	 * @returns {string} html template
	 */
	var createFeedbackMessage = function createFeedbackMessage(q) {
		// build the message
		var correct = q.isCorrect();
		var status = correct? "|:game.vocab.good_job:|" : "|:game.vocab.oops:|";
		var color = correct? "green" : "orange";
		var tag = 'game.categories.' + q.config.category.after('.') + '.' + (q.isCorrect() ? 'right': 'wrong');
		var messages = wombat.assets.getText(tag);

		// get a subtype-appropriate message, if available
		var message = "";
		if (messages[q.config.subtype]) {
			message += messages[q.config.subtype];
		} else {
			message += messages['general'];
		}

		// render the message
		var html = renderMessage(q, message);

		// finalize by returning the message inside the html template
		return wombat.assets.getAsset(settings.templates.feedback_message, {
			dom: false,
			render: true,
			replace: {
				color: color,
				status: status,
				text: html
			}
		});
	};


	/**
	 * Render a message to the user by substituting actual values for text tags
	 * @param {wombat.ict.assess.Question} q The question for which to render the message
	 * @param {String} message The html/text message to display to the user
	 * @returns {String}
	 */
	var renderMessage = function renderMessage(q, message) {
		var regex = {
			tld: /\.(com\.au|com\.br|com\.cn|com\.mx|com\.vn|com|net|org|co\.uk|co\.in|co\.ro|gov\.br|pl|us|cc|cd|cf|ck|su|sc|ru|co|bs|to|me|fr|it|mx|de|jp|tw|cn|br|kr|ca|au|cz|in|ro|vn)(?:\/|$)/,
			rest: /(https?:\/\/)(\S+\.)?([^\s\.]+)/,
			protocol: /https?:\/\//
		};

		// make replacements for "country" url category
		if (q.category === "url.country") {
			// replace the "|:country." part of text tags with the relevant country text tag
			//noinspection JSUnresolvedVariable
			message = message.replace(/\|:country\./g, "|:game.countries." + q.config.country + ".");

			// replace ".country:| with the relevant country
			//noinspection JSUnresolvedVariable
			message = message.replace(/\.country:\|/, ".countries." + q.config.country + ":|");
		}

		// replace the "|:site." part of text tags with the actual site's text tag
		message = message.replace(/\[site\]/g, "game.sites." + q.config.site);

		// grab the parts of the url in case they are needed
		var text = wombat.assets.render( q.config.uri ),
			match = regex.tld.exec( text ),
			sub = null,
			domain = '';

		// first, grab the tld from the string
		if( match ) {
			var tld = match[ 1 ];
			// remove the tld from the string and then test the rest of the string
			text = text.slice( 0, match.index );
			match = regex.rest.exec( text );

			// if the rest has a match, update the sub and domain
			if( match ) {
				sub = match[ 2 ] ? match[ 2 ].slice( 0, - 1 ) : null;
				domain = match[ 3 ] + "." + tld;
			}
		}

		match = regex.protocol.exec(q.config.uri);
		var protocol = (!match) ? null : match[0];

		//if it is in right to left, wrap everything in d-ltr spans
		if( wombat.global.rtl ) {
			// create html by replacing parts of the message
			return wombat.assets.render(message, {
				url: "<span class='d-ltr'>" + q.config.uri + "</span>",
				domain: "<span class='d-ltr'>" + domain + "</span>",
				subdomain: "<span class='d-ltr'>" + sub + "</span>",
				protocol: "<span class='d-ltr'>" + protocol + "</span>"
			});
		}
		else {
			// create html by replacing parts of the message
			return wombat.assets.render(message, {
				url: q.config.uri,
				domain: domain,
				subdomain: sub,
				protocol: protocol
			});
		}
	};


	/**
	 * Show the decision box once url is hovered
	 * @param e - hover event object
	 */
	var urlHover = function urlHover(e) {
		This._fire(This.EVENT.URL_ACTIVE, This.id);      // tell parent class that this box is active by passing the ID (which is used to find in array)

		// only add element to page if it's not already there
		if (!$.contains(document.documentElement, This.$decision_box[0])) {
			// make sure $decision_box is removed from the page?
			This.$decision_box.remove();

			// temporarily hide until positioned
			This.$decision_box.ghost(function() {
				// add box to page
				This.$decision_box.appendTo($page);

				if(e)
				{
					// get coordinates to place $decision_box at
					var coordinates = This._calculateDecisionPosition(e);

					// position box
					This.$decision_box.css({
						"position": "absolute",
						"left": coordinates.left+"px",
						"top": coordinates.top+"px"
					});
				}


				// fire the ghosted event so that subclasses can modify positioning if necessary
				This._fire(This.EVENT.URL_GHOSTED);

			});

			// setup controls for this decision box
			This.$decision_box.mouseenter(urlHover)
				.mouseleave(urlLeave);
		}
	};

	/**
	 * Hide the decision box (after a timeout) when the url hover is complete
	 */
	var urlLeave = function urlLeave() {
		// clear the timeout to hide decision box (if it exists)
		$.doTimeout("url"+This.id);

		$.doTimeout("url"+This.id, settings.decision_box.delay_hide, function() {
			This.$decision_box.remove();	 // remove the DP
			This._fire(This.EVENT.URL_ACTIVE, null);  // deactivate
		});
	};

	// call init to initialize the round
	_init_();
};

/** Makes base class extensible */
wombat.extensible.mix(wombat.ict.plugins.url.DecisionPoint);

/** Mix in the Events mixin */
wombat.events.mix(wombat.ict.plugins.url.DecisionPoint);

/** Set up events */
wombat.ict.plugins.url.DecisionPoint.prototype.EVENT = {
	URL_GHOSTED: 'url_ghosted',
	URL_ACTIVE: 'url_active',
	URL_COMPLETE: 'url_complete',
	SHOW_MESSAGE: 'show_message'
};


/********************************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description: The Round-level class for the URL plugin
 * Author:		Chris A Vaccarello, Jason R. Brubaker
 * Date:        4/9/14
 *******************************************************************************/

wombat.require('wombat.ict.plugins.url.DecisionPoint');
wombat.register('wombat.ict.plugins.url.PluginRound');

/**
 * A Phishing.Round object is a special kind of assess.Assessment object that represents a round of a phishing training game
 * @param id
 * @param $page
 * @param options
 * @constructor
 * @memberOf wombat.ict.plugins.url
 * @extends wombat.ict.assess.Assessment
 */
wombat.ict.plugins.url.PluginRound = function PluginRound(id, $page, options) {
	/**
	 * Get This alias while initializing Assessment superclass (which is a subclass of LoggingObject)
	 * @type {wombat.ict.plugins.url.PluginRound}
	 */
	var This = this.__init__(id);


	/*****************************************************************************************************************
	 *  PROTECTED VARIABLES (should go into some sort of base plugin eventually)
	 *****************************************************************************************************************/
	this._id = $page.attr('id').replace('-', '.');

	/*****************************************************************************************************************
	 *  PUBLIC VARIABLES
	 *****************************************************************************************************************/
	/**
	 * Settings
	 */
	this.settings = $.extend(true, {
		elements: {
			summary_item_container: ".item-container"
		},
		templates: {
			summary_page: "html.templates.summary",
			summary_item: "html.templates.item",
			stamp: "html.templates.summary-stamp"
		},

		// grid or none (none = css required to position every box)
		positioning: "grid",
		grid: {
			rows: 5,
			columns: 5
		},

		round_status: {
			init: {
				points: 0,
				lives: 3,
				time: 120
			},
			event_outcomes: {
				visit: {
					correct: { points: 10 },
					incorrect: { lives: -1 }
				},
				avoid: {
					correct: { points: 10 },
					incorrect: { time: -10 }
				}
			}
		},

		message: {
			timeout: 5000,
			offset: {
				left: 0,
				top: 0
			}
		},

		url_constructor: wombat.ict.plugins.url.DecisionPoint,
		url_element: {
			elements: {
				page: $page,
				container: $page.find(".url-container")
			}
		},

		// ContainerController
		_controller: null,

		// array of questions
		_questions: [],

		// default section configuration (override in subclass)
		_section: {
			to_ask: 8,
			to_pass: 6,
			select: {
				property: 'correct',
				visit: [3, null],
				avoid: [3, null]
			},
			scoring_fn: function() {
				return This.state.points;
			},
			scoring_init: null
		}
	}, options);

	/**
	 * Keep track of the RoundState (status)
	 * @type {wombat.ict.assess.RoundState}
	 */
	this.state = null;

	/**
	 * The current round number
	 * @type {number}
	 */
	this.round_id = -1;

	/**
	 * Array of url elements
	 * @type {wombat.ict.plugins.url.DecisionPoint}
	 */
	this.url_elements = [];

	/**
	 * Array of completed url elements (for use in summary page)
	 * @type {wombat.ict.plugins.url.DecisionPoint}
	 */
	this.completed_url_elements = [];

	/**
	 * The currently-active URL
	 * @type {number}
	 */
	this.active_url = null;


	/*****************************************************************************************************************
	 *  PRIVATE VARIABLES
	 *****************************************************************************************************************/
	// setup some shortcuts for use in this class
	var settings = This.settings;

	/*****************************************************************************************************************
	 *  _INIT_
	 *****************************************************************************************************************/
	function _init_() {
		// log the call to init
		//noinspection JSUnresolvedFunction
		This._debug();

		// set round ID
		This.round_id = parseInt(LearningModule.getState().currentLessonState().id, 10);

		var $container = settings.url_element.elements.container;
		var available_width = $container.outerWidth() - 20; // -20 for scroll bar
		var available_height = $container.outerHeight();

		// calculate grid box width's and height's based on rows & columns and the available width/height
		settings.grid.width = Math.floor(available_width / settings.grid.columns);
		settings.grid.height = Math.floor(available_height / settings.grid.rows);

		// fix the URLs, then remember them in case of retrying
		fixUrls(settings._questions);

		// tell the section to expect all questions, if console flag is set
		if (wombat.ict.global_settings.all_questions) { settings._section.to_ask = settings._questions.length;}

		// create the section (only one in this type of quiz) from the _questions and _section settings
		This.nextSection($.extend({ qs: settings._questions }, settings._section));

		// select the questions for this quiz
		This.questions.select();

		// create RoundState & attach to state events
		This.state = new wombat.ict.assess.RoundState(settings.round_status);
		This.state.fireOn(This.state.EVENT.ENDED, function (status) { roundEnded(status); });
		This.state.newSection(true);                    // reset section points and restart timer


		// bind event to "Question" admin bar to be able to change questions
		LearningModule.attachToAdminBarEvent("Question", "question_changed", new wombat.Callback({
			c: This,
			allow_multiple: true,
			f: adminChangeQuestion
		}));
	}

	/*****************************************************************************************************************
	 *  PUBLIC FUNCTIONS
	 *****************************************************************************************************************/
	/**
	 * Start the round
	 */
	this.activate = function _activate() {
		this._info();

		// activate the DecisionPoints
		for (var i = 0; i < This.url_elements.length; i++) {
			This.url_elements[i].activate();
		}

		// disable right-clicking (to keep IE users from pausing the timer)
		if (!wombat.ict.global_settings.automation_mode) {
			$(document).on("contextmenu", function () {
				return false;
			});
		}

		// set the state's status to IN_PROGRESS
		This.state.begin();

		This.state.timer.start();
	};

	/**
	 * Do plugin-level cleanup
	 */
	this.cleanUp = function cleanUp() {
		// re-enable right-clicking
		$(document).off("contextmenu");
	};


	/*****************************************************************************************************************
	 *  PROTECTED FUNCTIONS
	 *****************************************************************************************************************/
	/**
	 * Create, position, and add URL class elements to their appropriate container
	 * @param {Array} [extra_events] - extra events attachment configurations
	 * @protected
	 */
	this._createDecisionPoints = function _createDecisionPoints(extra_events) {
		extra_events = extra_events || [];

		// create & append URL boxes to the screen
		for (var i=0; i<settings._section.to_ask; i++) {
			var q = This.questions.selected[i];

			// create DecisionPoint class
			var urlBox = new settings.url_constructor(i, This.state, q, $.extend({}, settings.url_element));

			// attach to events
			urlBox.fireAttach($.merge([
				{ type: urlBox.EVENT.URL_ACTIVE, cb: urlActive },
				{ type: urlBox.EVENT.URL_COMPLETE, cb: urlComplete },
				{ type: urlBox.EVENT.SHOW_MESSAGE, cb: urlMessage }
			], extra_events));

			var row_num = Math.floor(i / settings.grid.columns);
			var col_num = Math.floor(i % settings.grid.columns);

			// start coordinates of this row/column in grid
			var grid_x = col_num * settings.grid.width;
			var grid_y = row_num * settings.grid.height;

			var x = Math.randomInt(grid_x, grid_x + settings.grid.width - urlBox.dimensions.width - urlBox.dimensions.margin.right - urlBox.dimensions.margin.left);
			var y = Math.randomInt(grid_y, grid_y + settings.grid.height - urlBox.dimensions.height - urlBox.dimensions.margin.bottom - urlBox.dimensions.margin.top);

			// position url boxes based on "positioning" (grid or none) or no_randomness mode
			if (settings.positioning === "grid" || wombat.ict.global_settings.all_questions) {
				if (wombat.ict.global_settings.no_randomness) {
					urlBox.positionBox(grid_x, grid_y);
				} else {
					urlBox.positionBox(x, y);
				}
			}

			// add urlBox to array
			This.url_elements[i] = urlBox;
		}
	};

	/**
	 * End the round
	 * @param {string} round_status - the final status of the round
	 */
	this._roundEnded = function _roundEnded(round_status) {
		//noinspection JSUnresolvedFunction
		This._debug(round_status);

		// deactivate any remaining decision points
		for (var j = 0; j < This.url_elements.length; j++) {
			This.url_elements[j].deactivate();
		}

	};

	/**
	 * Get a DecisionPoint object by passing in the question_id
	 * @param {String} question_id
	 * @returns {wombat.ict.plugins.url.DecisionPoint}
	 * @protected
	 */
	this._getDPByQuestionId = function _getDPByQuestionId(question_id) {
		/**
		 * @type {wombat.ict.plugins.url.DecisionPoint}
		 */
		var el;

		// find
		for (var i = 0; i < This.url_elements.length; i++) {
			var url = This.url_elements[i];
			if (url.question.id === question_id) {
				el = url;
				break;
			}
		}

		// return
		return el;
	};


	/**
	 * Placeholder for showing a message
	 * @param {string} message The message to show
	 * @param {boolean} [teach] Optional setting for if this message is a "teach" message, which is more important and should be overlapping everything else (TM-1381)
	 * @protected
	 */
	this._showMessage = function _showMessage(message, teach) { };


	/*****************************************************************************************************************
	 *  PRIVATE FUNCTIONS
	 *****************************************************************************************************************/
	/**
	 * Change question via the admin bar interface
	 * @param {string} new_question_id
	 */
	var adminChangeQuestion = function adminChangeQuestion(new_question_id) {
		var index, q;
		for (var i=0; i<This.questions.selected.length; i++) {
			var question = This.questions.selected[i];
			if (question.id === new_question_id) {
				index = i;
				break;
			}
		}

		// Only highlight an element if it was find and the roundstate isn't "complete"
		if(index !== undefined && !This.state.isComplete()) {
			// get decision point class
			var dp = This.url_elements[index];

			// show/select question (simulate javascript mouse event with pageX and pageY)
			var offset = dp.$element.offset();
			dp.select({pageX: offset.left, pageY: offset.top});
		}
	};


	/**
	 * End the round - This is done so that the function can be overridden and still called from the event
	 * @param {string} status - the final status of the round
	 */
	var roundEnded = function roundEnded(status) {
		This._roundEnded(status);
	};

	/**
	 * Set the active url (null if disabling)
	 * @param i - index in Round.url_elements array
	 */
	var urlActive = function urlActive(i) {
		// clear old timeout
		$.doTimeout("url"+This.active_url);

		// if this is a different index, cancel the old question (if one exists)
		if (This.active_url !== i && This.active_url !== null) {
			This.url_elements[This.active_url].question.cancel();
			This.url_elements[This.active_url].$element.removeClass("hover");
		}

		// if the new index isn't null, begin the associated question
		if (i !== null) {
			This.url_elements[i].question.begin();
			This.url_elements[i].$element.addClass("hover");
		}

		// remember the new active_url index (may be null)
		This.active_url = i;
	};

	/**
	 * once url is complete, remove from list and check if round completed
	 * @param i - index in Round.url_elements array
	 */
	var urlComplete = function urlComplete(i) {
		var total_complete = This.completed_url_elements.length;

		// add completed url to new array
		This.completed_url_elements[total_complete] = This.url_elements[i];

		// if arrays are same length, we're done
		if (This.url_elements.length == This.completed_url_elements.length) {
			if (This.state.status == This.state.STATUS.IN_PROGRESS) {
				if (This.isPassed()) {
					This.state.complete();
				} else {
					This.state.failed();
				}

			}
		}
		else {
			var cq = This.current_question;
			if (!wombat.ict.global_settings.automation_mode) {
				window.setTimeout(function (){
					if(This.current_question && This.current_question.isComplete()){
						cq.deactivate();
					}
				}, This.settings.message.timeout);
			}
		}
	};

	/**
	 * Fix the URLs by getting localized text
	 * @param {Object} url_list The urls to fix
	 * @param {String} url_list.id
	 * @param {String} url_list.uri
	 * @param {String} url_list.site
	 * @param {String} url_list.category
	 * @param {String} url_list.correct
	 * @param {Boolean} url_list.scam
	 */
	var fixUrls = function fixUrls(url_list) {
		//noinspection JSUnresolvedFunction
		This._debug();
		var url;

		// loop through chosen urls
		for (var i=0; i<url_list.length; i++) {
			url = url_list[i];

			// replace [site] with actual site tag
			url.uri = url.uri.replace(/\[site\]/g, "game.sites." + url.site);

			// localize uri
			url.uri = wombat.utility.localizeHtmlPaths(url.uri);
		}
	};

	/**
	 * Handles message event from URL
	 * @param html
	 * @param {boolean} [teach] Optional setting for if this message is a "teach" message, which is more important and should be overlapping everything else (TM-1381)
	 */
	var urlMessage = function urlMessage(html, teach) {
		This._showMessage(html, teach);
	};


	// call init to initialize the round
	_init_();
};

/** Extend from wombat.ict.assess.Assessment */
wombat.extensible.extend(wombat.ict.assess.Assessment, wombat.ict.plugins.url.PluginRound);

//# sourceMappingURL=url.js.map