/**********************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description: Plugin used by other plugins to display question
 *              indicators for a quiz. Converted from original by JRB.
 * Author: Jason R Brubaker
 * Date: 2/20/14
 **********************************************************************/

/**
 * Handle the rendering of indicators (question number, questions correct, etc) for a quiz
 * @param {Object} options
 * @param {Number} [options.count=5] The total number of questions presented to the user
 * @param {String} [options.class_name] The name of the class of the indicators
 * @param {Object} [options.text_tags] Text tags to use in the "alt" tag of the indicators
 * @param {String} [options.text_tags.pending=|:indicators.pending:|] Text tag in alt when question has yet to be answered
 * @param {String} [options.text_tags.correct=|:indicators.correct:|] Text tag in alt when question is answered correctly
 * @param {String} [options.text_tags.correct=|:indicators.incorrect:|] Text tag in alt when question is answered INcorrectly
 * @constructor
 * @extends wombat.ict.plugins.Base
 */
wombat.ict.plugins.QuizIndicators = function(options) {

	/**
	 * Alias returned from SuperConstructor
	 * @type {wombat.ict.plugins.QuizIndicators}
	 */
	var This = this.__init__();

	/**
	 * Array of indicator elements
	 * @type {Object[]}
	 */
	var elements = [];

	/**
	 * Which question we're on
	 * @type {Number}
	 */
	var index = 0;

	/**
	 * Count of correct answers
	 * @type {Number}
	 */
	var correct_count = 0;

	/**
	 * Keep track of the current question
	 * @type {Number}
	 */
	var current_question = 0;

	/**
	 * The container for a textual representation of the status
	 * @type {Object}
	 */
	var $text_status;

	/**
	 * If specified, shows the current question number
	 * @type {Object}
	 */
	var $question_num;

	// extend base settings w/ plugin defaults & options param
	this._settings = $.extend(true, This._settings, {
		count: 5,
		templates: {
			indicator: 'ict-templates.indicator'
		},
		text_tags: {
			pending: '|:indicators.pending:|',
			correct: '|:indicators.correct:|',
			incorrect: '|:indicators.incorrect:|'
		},
		class_name: 'ict-quiz-indicator'
	}, options);

	/**
	 * Constructor
	 * @private
	 */
	function _init_() {  }

	/* Public methods **************************************************/

	/**
	 * Render the indicators
	 * @param {Object} $container jQuery element object
	 * @param {Object} [$text_container] Optional jQuery element to show the status as text
	 * @param {Object} [$question_num_container] Optional jQuery element to show the question number as text
	 */
	this.render = function render($container, $text_container, $question_num_container) {
		// render each indicator
		for (var i= 0; i<This._settings.count; i++) {
			// render the indicator template with the "pending" text as the title
			elements[i] = wombat.assets.getHtml(This._settings.templates.indicator, {
					replace: {title: This._settings.text_tags.pending},
					dom:true}
			);

			// add in the correct id
			elements[i].attr('title',elements[i].attr('title').replace('|:id:|', (i+1).toString()));

			// add question number to indicator
			elements[i].append(i+1);

			// add indicator to the container
			$container.append(elements[i]);
		}

		// save references
		$text_status = $text_container;
		$question_num = $question_num_container;
	};

	/**
	 * Indicate a question has begun (only necessary when displaying question #)
	 * @param {Number} [question_index] - optional index to track what question we're on in question list
	 */
	this.questionBegun = function questionBegun(question_index) {
		// set the current question index
		current_question = question_index;

		// set current questions indicator to "current"
		elements[index].addClass("current");
	};

	/**
	 * Mark the current question correct or incorrect
	 * @param {Boolean} correct Was the question completed successfully?
	 */
	this.questionComplete = function questionComplete(correct) {
		// increment correct count
		if (correct) { correct_count++; }


		// update the correct indicator with the right title & class
		var correct_string = correct ? 'correct' : 'incorrect';
		elements[index].attr('title', wombat.assets.render(This._settings.text_tags[correct_string]));
		elements[index].attr('title',elements[index].attr('title').replace('|:id:|', (index+1).toString()));
		elements[index].removeClass("current").addClass(correct_string).empty().append("&nbsp;");

		// increment counter
		index++;
	};

	// call constructor
	_init_();
};

/** Extend QuizIndicators from plugin.Base */
wombat.extensible.extend(wombat.ict.plugins.Base, wombat.ict.plugins.QuizIndicators);

/** Configure assets */
wombat.ict.plugins.QuizIndicators.ASSETS = {
	"images": [
		"<:path tag='ict.plugins' :>/quizindicators/img/indicators.png"
	]
};
