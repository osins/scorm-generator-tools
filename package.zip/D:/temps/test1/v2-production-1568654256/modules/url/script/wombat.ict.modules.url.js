/********************************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description:	Defines the wombat.ict.modules.url namespace and functions called by various screens in the module
 * Author:		Jason R Brubaker
 * Date:        4/2/14
 *******************************************************************************/

wombat.register('wombat.ict.modules.url');

/** Namespace for the URL Training module **/
wombat.ict.modules.url = {

	/** Prepare the layout after the splash screen by showing the header */
	prepLayout: function() {
		$('#ict-header').css('visibility', 'visible');
	},


	/** Functions for splash pages **/
	splash: {
		prep: function(data, params, state, $page) {
			var id = LearningModule.getState().currentLessonState().id;
			$page.find('h2').append(wombat.assets.getText('lesson_titles.'+id));
		},

		/**
		 * Begin a count down display starting at 3, for pages just prior to the game sections
		 */
		beginCountdown: function(data, params) {
			var $splash = $('#game-splash');
			var $time = $splash.find(".round-countdown");

			$.easing.jswing = $.easing.swing;
			$.extend($.easing,
				{
					easeInOutQuart: function (x, t, b, c, d) {
						if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
						return -c/2 * ((t-=2)*t*t*t - 2) + b;
					}
				});


			var countdown = function(i) {
				if (i > 0) {
					$time.empty().append(i);
					$time.css({"font-size":"190px"});

					$time.animate({"font-size":"80px"}, 1000, 'easeInOutQuart', function() {
						countdown(i-1);
					});
				} else
					startRound();
			};

			var startRound = function() {
				$splash.hide();
				wombat.ict.Instruct.finished({}, true);
			};

			countdown(3);
		}
	},

	/** Functions for the teaching screens **/
	teach: {
		/**
		 * @type {wombat.ict.InstructButtonHelper}
		 */
		helper: null,

		/**
		 * jQuery collection of steps
		 */
		$steps:null,

		/**
		 * jQuery element containing teaching contents
		 */
		$contents:null,

		/**
		 * Prepare the teaching screen
		 * @param data
		 * @param params
		 * @param state
		 * @param $screen
		 */
		prep: function(data, params, state, $screen) {
			// alias the teach object
			var This = wombat.ict.modules.url.teach;

			// get & mask the contents
			This.$contents = $screen.find('.teach-contents').mask();

			// get $steps collection
			This.$steps = $screen.find('.teach-bg .step');

			// set up the button helper
			This.helper = new wombat.ict.InstructButtonHelper(params.controller, params.mapping, {states:{ begin:0, end: This.$steps.length - 1}});

			// attach to events
			This.helper.fireAttach([
				{ type: This.helper.EVENT.BUTTON_CLICKED, cb: function(which, step) {
					// which step are we going to?
					var new_step = step + ((which === This.helper.BUTTONS.NEXT) ? 1 : -1);

					// get the $step elements
					var $cur_step = This.$steps.eq(step);
					var $new_step = This.$steps.eq(new_step);

					// hide any assist elements for the current step (if they aren't in the new step)
					This.$contents.find('.assist' + step + ':not(.assist' + new_step + ')').hideMe();

					// hide current step
					$cur_step.hideMe(function() {
						// ghost step & update mask for new step
						$cur_step.ghost(function() {
							// unmask/remask contents
							if ($new_step.attr('data-mask') === 'true') {
								This.$contents.mask();
							} else {
								This.$contents.unmask();
							}
						});

						// show new step
						$new_step.showMe(function() {
							// let the helper know we're on the new step
							This.helper.changeState(new_step);

							// The first lesson has a tutorial after the "teach" section, so it should be ignored here.
							// Otherwise wait until the last step to update the button text
							var currentLesson = window.LearningModule.getState().lesson_index;
							if (currentLesson !== 0 && new_step === This.$steps.length-1 ) {
								// Change button text to say "Start" instead of "next" on final page
								params.controller.changeButtonText(params.mapping.next.name, "|:buttons.start:|");
							} else {
								// Otherwise, make sure the text says "next"
								params.controller.changeButtonText(params.mapping.next.name, "|:buttons.next:|");
							}

							This.helper.clickHandled();
						});

						// show any assist elements for the new step
						This.$contents.find('.assist' + new_step).showMe();
					});
				}},
				{ type: This.helper.EVENT.END_STATE_REACHED, cb: function() {
					wombat.ict.Instruct.finished();
				}}
			]);
		},

		/**
		 * Clean up instruct
		 * @param data
		 * @param params
		 * @param state
		 * @param $screen
		 */
		cleanUp: function(data, params, state, $screen) {
			//hide the buttons if it isn't the first lesson, because the first lesson has a screen after it
			if(LearningModule.getState().lesson_index !== 0) {
				params.controller.hideButton(params.mapping.prev.name, null, true);
				params.controller.hideButton(params.mapping.next.name, null, true);
			}
			params.controller.changeButtonText(params.mapping.next.name, "|:buttons.next:|");
			wombat.ict.modules.url.teach.helper.cleanUp();
		}
	},

	/** Functions for the tutorial **/
	tutorial: {
		/**
		 * @type {wombat.ict.InstructButtonHelper}
		 */
		helper: null,

		/**
		 * jQuery collection of steps
		 */
		$steps:null,

		/**
		 * Other jQuery elements
		 */
		elements: {
			$page: null,
			$area: null,
			$status: null,
			$step: null,
			$box: null,
			$cursor: null,
			$designation: null,
			$subtitle: null
		},

		/**
		 * Prepare for the tutorial
		 */
		prep: function prep(data, params, state, $page) {
			// alias
			var Tutorial = wombat.ict.modules.url.tutorial;

			// get subtitle text elements, swap subtitle text
			Tutorial.elements.$designation = $(".ict-lesson-designation");
			Tutorial.elements.$subtitle = $(".ict-lesson-title");

			Tutorial.elements.$designation.attr("data-text-original", Tutorial.elements.$designation.text()).text(wombat.assets.getText("tutorial.designation"));
			Tutorial.elements.$subtitle.attr("data-text-original", Tutorial.elements.$subtitle.text()).text(wombat.assets.getText("tutorial.subtitle"));

			// save $page, add a class to it to position browsers
			Tutorial.elements.$page = $page.addClass('round1');

			// save game area, status bar
			Tutorial.elements.$area = $('#game-area');
			Tutorial.elements.$status = $('#status-area');

			// show status area
			Tutorial.elements.$status.showMe();

			// get $steps collection
			Tutorial.$steps = Tutorial.elements.$page.find('.step');

			// show & place browsers
			Tutorial.elements.$area.find('.browser').show().each(function() {
				var $this = $(this);
				var old_position = $this.position();
				var new_css = {
					top: (old_position.top - $this.outerHeight() / 2) + 'px',
					left: (old_position.left - $this.outerWidth() / 2) + 'px'
				};
				$this.css(new_css);
			});

			// set up the button helper
			Tutorial.helper = new wombat.ict.InstructButtonHelper(params.controller, params.mapping, {
				states: { begin:0, end: 2, initial: -1},
				text: { next: '|:buttons.next:|' }
			});

			// attach to events
			Tutorial.helper.fireAttach([
				{ type: Tutorial.helper.EVENT.BUTTON_CLICKED, cb: function(which, step) {

					// set new step
					var new_step = step;
					if (which === Tutorial.helper.BUTTONS.NEXT) { new_step ++; }
					else { new_step --; }

					// show new step
					Tutorial.showStep(new_step, params);

				}},
				{ type: Tutorial.helper.EVENT.END_STATE_REACHED, cb: function() {
					wombat.ict.Instruct.finished();
				}}
			]);

		},

		// begin by showing the first step
		begin: function begin() {
			// show first step
			wombat.ict.modules.url.tutorial.showStep(0);
		},

		// clean up by hiding the status area
		cleanUp: function cleanUp(data, params, state, $screen) {
			var Tutorial = wombat.ict.modules.url.tutorial;

			// hide status area
			Tutorial.elements.$status.hideMe();

			// revert designation & subtitle text
			Tutorial.elements.$designation.text(Tutorial.elements.$designation.attr('data-text-original'));
			Tutorial.elements.$subtitle.text(Tutorial.elements.$subtitle.attr('data-text-original'));

			// reset button
			params.controller.hideButton(params.mapping.prev.name, null, true);
			params.controller.hideButton(params.mapping.next.name, null, true);
			params.controller.changeButtonText(params.mapping.next.name, "|:buttons.next:|");
		},

		// show a new step
		showStep: function showStep(step, params) {
			// get some variables
			var Tutorial = wombat.ict.modules.url.tutorial;		// alias for tutorial's namespace
			var old_step = Tutorial.helper.state;
			var $old_step = Tutorial.$steps.eq(old_step);
			Tutorial.elements.$step = Tutorial.$steps.eq(step);			// the new step's containing element
			var $messages = Tutorial.elements.$step.find('.message');	// all of the messages in this step
			var message_counter = -1;    								// which message in the step are we on?


			// create a recursive function to show all messages in the new step
			function showMessageRecursive() {
				// increment message counter
				message_counter ++;

				// if we aren't done, show the next message
				if (message_counter < $messages.length) {
					Tutorial.showMessage($messages, message_counter, showMessageRecursive)
				}
			}

			// start by hiding the old step container
			$old_step.hideMe(function() {
				// reset messages
				$old_step.find('.message').hide();

				// do we need to call a reset function?
				if(Tutorial.custom_actions[old_step.toString()]) {
					Tutorial.custom_actions[old_step.toString()].reset();
				}

				// show the new step container
				Tutorial.elements.$step.show();

				// let the helper know we're on the new step
				Tutorial.helper.changeState(step);

				// Change button text to say "Start" instead of "next" on final page
				if( step === 2 ) {
					params.controller.changeButtonText(params.mapping.next.name, "|:buttons.start:|");
				}

				Tutorial.helper.clickHandled();

				// show messages until we're done
				showMessageRecursive();
			});

		},


		// show a single message
		showMessage: function showMessage($messages, counter, callback) {
			// get alias
			var Tutorial = wombat.ict.modules.url.tutorial;

			// get current step as a string
			var step = Tutorial.helper.state.toString();

			// get current message
			var $message = $messages.eq(counter);

			// create a callback function to call the passed-in callback after 1.2 seconds
			function doCallback() {
				// default animation duration
				var duration = (wombat.ict.global_settings.no_animations)? 0: 400;

				$.doTimeout('tutorial', 1200, callback);
			}

			// do we have a custom action for this message?
			if (Tutorial.custom_actions[step] && Tutorial.custom_actions[step][counter.toString()]) {
				// yes, show message & run function concurrently, pass callback to function
				$message.showMe();
				Tutorial.custom_actions[step][counter.toString()](doCallback);
			} else {
				// no custom action. show message & pass the showMe function the callback
				$message.showMe(doCallback);
			}
		},

		// settings for step 0
		settings: {
			box_css: {top: '247px', left: '425px', 'z-index': 6}
		},

		// custom actions (only on step 0 right now)
		custom_actions: {
			"0": {
				// show hover box & cursor
				"0": function firstMessage(callback) {
					// get alias
					var Tutorial = wombat.ict.modules.url.tutorial;

					// get the hover box, apply the css & append it to the step
					Tutorial.elements.$box = wombat.assets.getAsset('html.templates.hover-box', {dom:true, replace: { url: '|:tutorial.step0.url.good:|' }});
					Tutorial.elements.$box.css(Tutorial.settings.box_css).hide().appendTo(Tutorial.elements.$step);

					// get the cursor
					Tutorial.elements.$cursor = Tutorial.elements.$area.find('#cursor');

					// show the hover box & the cursor, then call the callback
					Tutorial.elements.$cursor.showMe();
					Tutorial.elements.$box.showMe(callback);
				},

				// move cursor
				"1": function secondMessage(callback) {
					// get alias
					var Tutorial = wombat.ict.modules.url.tutorial;

					// add hover class to button
					Tutorial.elements.$box.find('a.top').addClass('hover');

					// move cursor
					$('#cursor').animate({ left: '+=40', top: '-=15' }, 300, callback);
				},

				// switch url, move cursor again
				"2": function thirdMessage(callback) {
					// get alias
					var Tutorial = wombat.ict.modules.url.tutorial;

					// replace the box with a new one
					var $new_box = wombat.assets.getAsset('html.templates.hover-box', {dom:true, replace: { url: '|:tutorial.step0.url.bad:|' }});
					$new_box.css(Tutorial.settings.box_css);
					Tutorial.elements.$box.replaceWith($new_box);
					Tutorial.elements.$box = $new_box;

					// move the cursor down
					Tutorial.elements.$cursor.animate({ top: '+=35' }, 300, callback);

					// add hover class to button
					Tutorial.elements.$box.find('a.bottom').addClass('hover');
				},

				// reset everything
				"reset": function reset(callback) {
					// get alias
					var Tutorial = wombat.ict.modules.url.tutorial;

					Tutorial.elements.$box.remove();
					Tutorial.elements.$cursor.css({top:'250px', left:'430px'});
				}
			}
		}
	},

	/** Functions for the game rounds **/
	game: {

		/**
		 * @type wombat.ict.modules.url.Round
		 */
		round: null,

		/**
		 * Initialize a round
		 */
		initRound: function(data, params, state, $page) {
			var config = data[0];

			wombat.ict.assess.current_assessment = new wombat.ict.modules.url.Round(config.id, $page, $('#status-area'), {
				_controller: params.controller,
				_questions: config.questions
			});
		},

		/**
		 * Begin a round
		 */
		beginRound: function() {
			wombat.ict.assess.current_assessment.activate();
		},

		/**
		 * Tell the game that the round is complete
		 */
		cleanUpRound: function() {
			wombat.ict.assess.current_assessment.cleanUp();
			wombat.ict.assess.current_assessment = null;
		}

	}
};

/********************************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description:	Defines a Browser class to extend the plugins.url.DecisionPoint class
 * Author:		Jason R Brubaker
 * Date:        4/2/14
 *******************************************************************************/

wombat.require('wombat.ict.modules.url');
wombat.register('wombat.ict.modules.Browser');

/**
 * The decision point for the URL Training module is rendered as a browser that the user must hover over
 * @param index
 * @param state
 * @param question
 * @param options
 * @constructor
 * @extends wombat.ict.plugins.url.DecisionPoint
 * @mixes wombat.extensible.Mixin
 */
wombat.ict.modules.url.Browser = function Browser(index, state, question, options) {
	/**
	 * Define default settings
	 * @type {Object}
	 */
	var settings = {
		elements: {
			page: null,
			container: null
		},
		selectors: {
			decision_box: '.hover-box'
		},
		classes: {
			cracked: 'cracked',
			stage: 'stage'
		},
		templates: {
			url_box: "html.templates.browser",
			decision_box: "html.templates.hover-box",
			feedback_message: "url.html.message",
			status_change: "html.templates.status-change"
		},
		decision_box: {
			delay_hide: 1000,
			offset: {
				left: 0,
				top: 0
			}
		},
		total_dps: 8,

		// configure animation variables for decision displays
		animation: {
			drop: { duration: 400, delta: 75 },
			cracking: { duration: 400, delay: 5 },
			fade: { duration: 350, delay: 25 },
			status: { delta: 25, duration: 1000 }
		}
	};

	$.extend(true, settings, options);


	/**
	 * Call super-constructor (returns alias)
	 * @type {wombat.ict.modules.url.Browser}
	 */
	var This = this.__init__(index, state, question, settings);


	/**
	 * Initialize object
	 * @private
	 */
	function _init_() {
		// create the DOM elements
		This._createElements();

		// attach to this element's own url_ghosted event
		//noinspection JSUnresolvedFunction
		This.fireOn(This.EVENT.URL_GHOSTED, modifyUrlPositioning);
	}

	/*****************************************************************************************************************
	 *  PRIVATE VARIABLES
	 *****************************************************************************************************************/
	var $page = settings.elements.page;


	/*****************************************************************************************************************
	 *  PUBLIC METHODS
	 *****************************************************************************************************************/
	/**
	 * Visit url
	 * @type {Function}
	 */
	this.decisionVisit = this._override('decisionVisit', function decisionVisit() {
		var changes = This._super_.decisionVisit();
		handleDecision(changes);
	});

	/**
	 * Avoid the url
	 * @type {Function}
	 */
	this.decisionAvoid = this._override('decisionAvoid', function decisionAvoid() {
		var changes = This._super_.decisionAvoid();
		handleDecision(changes);
	});

	/*****************************************************************************************************************
	 *  PROTECTED METHODS
	 *****************************************************************************************************************/
	/**
	 * Calculate the position for the decision element
	 * @param e - the event object that triggered this call
	 * @type {Function}
	 */
	this._calculateDecisionPosition = this._override('_calculateDecisionPosition', function calculateDecisionPosition(e) {
		return $page.globalToLocal(new StandardPosition(e.pageY, e.pageX));
	});

	/**
	 * Create the URL elements
	 * @type {Function}
	 * @private
	 */
	this._createElements = this._override('_createElements', function _createElements() {
		// create main DecisionPoint element
		This.$element = wombat.assets.getAsset(settings.templates.url_box, {dom:true, replace: {
			index: index
		}});

		// create decision box (shown when DP is activated)
		This.$decision_box = wombat.assets.getAsset(settings.templates.decision_box, { dom: true, replace: {
			url: question.config.uri
		}});

		// add element to $container
		This.$element.appendTo(settings.elements.container).show();

		// figure out dimensions
		This.dimensions = {
			width: This.$element.outerWidth(),
			height: This.$element.outerHeight(),
			margin: {
				top: parseInt(This.$element.css("margin-top")),
				right: parseInt(This.$element.css("margin-right")),
				bottom: parseInt(This.$element.css("margin-bottom")),
				left: parseInt(This.$element.css("margin-left"))
			}
		};

		// adjust position based on width/height (centers on original css point)
		var old_position = This.$element.position();
		var new_css = {
			top: (old_position.top - This.dimensions.height / 2) + 'px',
			left: (old_position.left - This.dimensions.width / 2) + 'px'
		};
		This.$element.css(new_css);
	});


	/*****************************************************************************************************************
	 *  PRIVATE METHODS
	 *****************************************************************************************************************/
	/**
	 * Handle the decision event
	 * @param changes {{points: number, lives: number, time: number}} - what change occurred due to the decision made
	 */
	var handleDecision = function handleDecision(changes) {
		// remove the url box & decision box
		This.$decision_box.remove();

		// deactivate the element
		This.deactivate();

		// do not show animations if animations are disabled
		if (wombat.ict.global_settings.no_animations) {
			This.$element.hide();
		} else {
			// show the status changes
			displayStatusChange(changes);

			// animate based on the decision
			decisionAnimate(question.isCorrect());
		}
	};

	/**
	 * Animate the browser based on the decision's correctness
	 * @param correct
	 */
	var decisionAnimate = function decisionAnimate(correct) {
		// show browser animations
		if (correct) {
			This.$element.hideMe();
		} else {
			// define variables
			var anim = settings.animation;

			// animate fade
			This.$element.delay(anim.fade.delay).animate(
				{ opacity: 0 },
				{
					duration: anim.fade.duration,
					queue: false
				}
			);

			// animate drop
			This.$element.animate(
				{ top: '+=' + anim.drop.delta },
				{
					duration: anim.drop.duration,
					queue: false,
					complete: function() {
						$(this).remove();
					}
				}
			);

			// animate cracking
			var stage = { val: -1, prev: -1 };
			$(stage).delay(anim.cracking.delay).animate(
				{ val: 3 },
				{
					duration: anim.cracking.duration,
					step: function crackAnimate(now) {
						now = Math.ceil(now);
						if (now > stage.prev) {
							if (now === 0) {
								This.$element.addClass(settings.classes.cracked);
							}
							This.$element.addClass(settings.classes.stage + now);
							stage.prev = now;
						}
					}
				}
			);
		}
	};

	/**
	 * Display round status changes/animation
	 * @param changes {{points: number, lives: number, time: number}} - what change occurred due to the decision made
	 */
	var displayStatusChange = function displayStatusChange(changes) {
		// get position & width of  browser
		var params = This.$element.position();
		params.width = This.$element.outerWidth();

		// score change
		if (changes.points !== 0) {
			animateChangeElement('score', changes.points, '|:game.vocab.points:|', params);
		}

		// lives change
		if (changes.lives !== 0) {
			animateChangeElement('lives', changes.lives, '|:game.vocab.life:|', params);
		}
	};

	/**
	 * Animate an individual status change element
	 * @param {String} property The property name
	 * @param {Number} val The value of the change
	 * @param {String} label The label to give the status
	 * @param {Object} params The parameters of the browser element responsible for the change
	 */
	var animateChangeElement = function animateChangeElement(property, val, label, params) {
		// is value greater than 0
		var positive = val > 0;

		// create element
		var $el = wombat.assets.getAsset(settings.templates.status_change, { dom:true, replace: {
			property: property,
			sign: (positive ? '+' : '-'),
			value: Math.abs(val).toString(),
			label: label,
			color: positive ? 'green' : 'orange'
		}});

		// place on game invisibly
		$el.appendTo(This.$element.parent());

		// calculate placement
		var top = params.top - $el.outerHeight() - 10;
		var left = params.left + (params.width - $el.outerWidth())/2;

		// place, make visible, then animate
		$el.css('left', left+'px').css('top', top+'px').css('visibility', 'visible');
		$el.animate({ top: '-='+settings.animation.status.delta, opacity: 0}, settings.animation.status.duration, function() {
			$el.remove();
		});
	};

	/**
	 * Modify the URL's positioning
	 */
	var modifyUrlPositioning = function modifyUrlPositioning() {
		// get url wrapper & bar
		var $wrapper = This.$decision_box.find('.url-bar-wrapper');
		var $url = This.$decision_box.find('.url-bar');

		// reset $wrapper's left to 0
		$wrapper.css('left', '0');

		// get bounding rectangle of $url
		var rectangle = $url.getStandardBoundingRect();

		// get bounding rectangle of containing element
		var containing = settings.elements.container.getStandardBoundingRect();

		// does the url go over either the left or right bounds of the container?
		var diff_left = containing.left - rectangle.left;
		var diff_right = containing.right - rectangle.right;
		if (diff_left > 0) {
			$wrapper.css('left', '+=' + Math.round(diff_left + 2) + 'px');
		} else if (diff_right < 0) {
			$wrapper.css('left',  '-=' + Math.abs(Math.round(diff_right - 2)) + 'px');
		}

	};

	// initialize the object
	_init_();
};

/** Extend from plugins.url.DecisionPoint **/
wombat.extensible.extend('wombat.ict.plugins.url.DecisionPoint', wombat.ict.modules.url.Browser);



/********************************************************************************
 * (C) 2014 Wombat Security Technologies, Inc.
 * Description: A single round of the URL Module's game portion
 * Author:		Jason R Brubaker
 * Date:        4/2/14
 *******************************************************************************/


wombat.require('wombat.ict.modules.url');
wombat.require('wombat.ict.modules.Browser');
wombat.register('wombat.ict.modules.url.GameRound');


/**
 * A single round of the URL game - extends plugins.url.PluginRound
 * @param {string} round_id - the ID of this round
 * @param {jQuery} $page - the main content element containing the round
 * @param $status - the status area
 * @param {object} options - must pass in _controller and _questions, all others are overrides of default settings
 * @constructor
 * @extends wombat.ict.plugins.url.PluginRound
 */
wombat.ict.modules.url.Round = function Round(round_id, $page, $status, options) {

	/**
	 * Initialize superclass; save alias
	 * @type {wombat.ict.modules.url.Round}
	 */
	var This = this.__init__('url.round.' + round_id, $page, $.extend(true, {
		// selectors
		selectors: {
			status: {
				during: '.in-round',
				after: '.after-round'
			},
			feedback_container: '.chat-messages'
		},

		// templates
		templates: {
			feedback: "html.templates.feedback",
			round_over: "html.templates.round-over"
		},

		// grid only for "show_all_questions"
		grid: {
			rows: 4,
			columns: 5
		},

		// asset tag for summary
		summary_tag: "|:html.round-summary:|",

		// no grid; CSS will position the boxes
		positioning: "none",

		// configure RoundStatus object
		round_status: {
			/*init: {
			 time: 15
			 },*/
			rendering: {
				points: {container: $status.find('.in-round .score')},
				time: {container: $status.find('.in-round .time')},
				lives: {template: wombat.assets.getAsset('html.templates.lives'), container: $status.find('.in-round .lives') }
			},
			event_outcomes: {
				visit: {
					correct: { points: 10 },
					incorrect: { lives: -1 }
				},
				avoid: {
					correct: { points: 10 },
					incorrect: { points: -4, time: null }
				}
			}
		},

		// configure message offset & duration
		message: {
			timeout: 5000,
			offset: {
				left: 0,
				top: 0
			}
		},

		// the constructor to use for the decision points
		url_constructor: wombat.ict.modules.url.Browser,

		// to pass on to the decision point objects
		url_element: {
			elements: {
				page: $page,
				container: $page.find("#game-area")
			},
			events: [],
			total_dps: 8
		},

		// which button to use to review
		button_name: "global-center",

		// the ContainerController object
		_controller: null,

		// array of questions
		_questions: [],

		// section configuration
		_section: {
			to_ask: 8,
			to_pass: 6,
			select: {
				property: 'correct',
				visit: [3, null],
				avoid: [3, null]
			},
			scoring_init: null
		}
	}, options));

	/* ****************************************************************************************************************
	 *  PRIVATE VARIABLES
	 ** ***************************************************************************************************************/
	/** Contains game area **/
	var $game = $page.find("#game-area");

	/** Mask to cover game area **/
	var $mask = $game.find('.game-area-mask');

	/** Current feedback balloon (jQuery) */
	var $feedback;

	/** Is the button hijacked? {boolean} */
	var hijacked = false;

	/**
	 * Container for feedback balloon {jQuery}
	 */
	var $feedback_container = $page.find(This.settings.selectors.feedback_container);

	/**
	 * Elements used in review/feedback
	 */
	var $end_of_round = {
		review_message: null,
		summary: null
	};

	/*****************************************************************************************************************
	 *  _INIT_
	 *****************************************************************************************************************/
	function _init_() {
		// get round ID, add it to $page element as a class
		This.round_id = parseInt(round_id);
		$page.addClass('round' + round_id);

		// create decision points
		This._createDecisionPoints();
	}


	/*****************************************************************************************************************
	 *  PUBLIC METHODS
	 *****************************************************************************************************************/
	/**
	 * Activate the UI
	 * @type {Function}
	 * @private
	 */
	this.activate = this._override('activate', function _activate() {
		// call the original rounds activate function
		This._super_.activate();

		// wire up the decision buttons
		wireDecisionButtons();

		// hijack the center button & mark it to be enabled
		hijacked = true;
		This.settings._controller.hijackButton(This.settings.button_name, {
			callback: new wombat.Callback({
				c: This,
				f: controllerButtonClicked,
				allow_multiple: true
			})
		});
		This.settings._controller.delayEnable(This.settings.button_name);

		// set up status display
		$status.find('.in-round').show();
		$status.find('.after-round').hide();
		$status.show();

	});


	/**
	 * Clean up UI stuff
	 */
	this.cleanUp = this._override('cleanUp', function cleanUp() {
		This._super_.cleanUp();

		// release button
		releaseHijackedButton();

		// stop timer
		This.state.timer.stop(true);

		// hide the $status, revert classes, etc.
		$status.hideMe(function() {
			resetStatusDisplay();
			$status.removeClass('round-over');
		});

	});


	/*****************************************************************************************************************
	 *  PROTECTED METHODS
	 *****************************************************************************************************************/

	/**
	 * Show a message
	 * @param {string} message The message to show
	 * @param {boolean} [teach] Optional setting for if this message is a "teach" message, which is more important and should be overlapping everything else (TM-1381)
	 * @protected
	 * @type {Function}
	 */
	this._showMessage = this._override('_showMessage', function showMessage(message, teach) {
		// keep reference to existing feedback element
		var $old = $feedback;
		var fade = true;

		// if feedback already exists, cancel timeout, remember not to fade in
		if ($old) {
			$.doTimeout('game.feedback');
			fade = false;
		}

		// create new feedback from template
		$feedback = wombat.assets.getAsset(This.settings.templates.feedback, {dom:true, replace: {
			content: message
		}});

		// if this is a "teaching" information box, overlap it differently
		if (teach) $feedback_container.css("z-index", 9);
		else $feedback_container.css("z-index", 7);

		// ghost the feedback to add it
		$feedback.ghost(function feedbackGhosted() {
			$feedback.appendTo($feedback_container);		// add feedback

			// if old exists, remove it
			if ($old) {  $old.remove(); }
		});

		// now show feedback
		if (fade) {
			$feedback.showMe();
		} else {
			$feedback.show();
		}

		// set timer to hide if not in automation mode
		if (!wombat.ict.global_settings.automation_mode) {
			$.doTimeout('game.feedback', This.settings.message.timeout, function() {
				$feedback.hideMe();
			});
		}
	});

	/**
	 * Override _roundEnded
	 * @param {string} round_status - the final status of the round
	 * @protected
	 * @type {Function}
	 */
	this._roundEnded = this._override('_roundEnded', function _roundEnded(round_status) {
		This._super_._roundEnded(round_status);

		// if there's a decision box open, close it
		if (This.active_url !== null) {
			This.url_elements[This.active_url].decisionCancel();
		}

		$("#game").mask();

		// render a message box
		$end_of_round.review_message = wombat.assets.getAsset(This.settings.templates.round_over, { dom:true, replace: {
			status: round_status,
			title_class: (This.isPassed()) ? 'green' : 'red'
		}});

		// add message box to messages div & center it, then show it
		$end_of_round.review_message.appendTo($page).center({dir:'h'}).show();

		// time to review; show the review button
		This.settings._controller.delayShow(This.settings.button_name);
		This.settings._controller.updateButtons();
	});


	/*****************************************************************************************************************
	 *  PRIVATE METHODS
	 *****************************************************************************************************************/
	/**
	 * reset status area on completion
	 */
	var resetStatusDisplay = function resetStatusDisplay() {
		This.settings.round_status.rendering.points.container.empty().append("000");
		This.settings.round_status.rendering.time.container.empty().append("2:00");
		This.settings.round_status.rendering.lives.container.find(".life-indicator").removeClass("lives-0 lives-1 lives-2");
	};

	/**
	 * Wire the decision buttons
	 */
	var wireDecisionButtons = function wireDecisionButtons() {
		// user clicks the "visit" button
		$page.on('click', 'a.top', function handleVisitButton(e) {
			e.preventDefault();
			var dp = This.url_elements[This.active_url];
			dp.decisionVisit(e);
		});

		// user clicks the "avoid" button
		$page.on('click', 'a.bottom', function handleAvoidButton(e) {
			e.preventDefault();
			var dp = This.url_elements[This.active_url];
			dp.decisionAvoid(e);
		});

		// user clicks the "hint" button
		$page.on('click', 'a.left', function handleHintButton(e) {
			e.preventDefault();
			var dp = This.url_elements[This.active_url];
			dp.decisionTeach();
		})
	};

	/**
	 * Handle the controller button being clicked
	 */
	var controllerButtonClicked = function controllerButtonClicked() {
		$("#game").unmask();

		if (This.state.status === This.state.STATUS.SUMMARY) {

			// handle/release button
			This.settings._controller.handled();

			// remove stamp
			if ($end_of_round.stamp) { $end_of_round.stamp.remove(); }

			// hide mas
			$mask.hideMe();

			// hide summary container, call retry
			$end_of_round.summary.hideMe(function() {
				// restart the instruct
				LearningModule.restartInstruct();
			});

		} else {
			// handle button
			This.settings._controller.handled();

			// remove message
			$end_of_round.review_message.remove();

			// hide any feedback
			if (wombat.ict.global_settings.automation_mode) {
				$feedback.hideMe();
			} else {
				$.doTimeout('game.feedback', false);
			}

			// if we've passed, we should release control of the hijacked button & call finished()
			if (This.isPassed()) {
				releaseHijackedButton();
				wombat.ict.Instruct.finished({score: This.getScore()});
			}

			// show round summary
			showRoundSummary();
		}
	};

	/**
	 * Release the hijacked button
	 */
	var releaseHijackedButton = function releaseHijackedButton() {
		if (hijacked) {
			hijacked = false;
			This.settings._controller.releaseButton(This.settings.button_name, true);
		}
	};

	/**
	 * Show an end-of-round summary
	 */
	var showRoundSummary = function showRoundSummary() {
		// update status
		var end_status = This.state.status;
		This.state.updateStatus(This.state.STATUS.SUMMARY);

		// render the summary
		var $summary = This.renderSummary($game, createItemReplacement, This.settings.summary_tag, {
			heading: wombat.assets.render('|^end_of_round.~status~.heading^|', {status: end_status}),
			text: wombat.assets.render('|^end_of_round.~status~.text^|',  {status: end_status, round_id: round_id}),
			num: "<span class=\"page-current\">&nbsp;</span>",
			total: "<span class=\"page-total\">&nbsp;</span>",
			round_id: round_id
		});

		// "ghost" the summary so we can manipulate it without it being seen
		$summary.ghost(function() {
			// set up paging
			$summary.find('.summary-items').pageChildren({
				buttons: $summary.find('.paging-buttons'),
				indicators: {
					current: $summary.find('.page-current'),
					total: $summary.find('.page-total')
				}
			});

			// center the summary
			$summary.center({ dir:'vh' });

			// add stamp if incomplete
			if (!This.isCompleted()) {
				// create, append, & center stamp
				var $incomplete_stamp = wombat.assets.getAsset(This.settings.templates.stamp, {dom:true})
					.appendTo($summary).
					center({dir:'vh'});

				// set up mouse events for showing/hiding stamp
				$summary.mouseenter(function() {
					var duration = (wombat.ict.global_settings.no_animations)? 0: 400;
					$incomplete_stamp.stop(true).animate({
						"opacity": 0,
						"-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)",
						"filter": "alpha(opacity=0)"
					}, duration, function() { $(this).hide(); })
				})
					.mouseleave(function(){
						var duration = (wombat.ict.global_settings.no_animations)? 0: 800;
						$incomplete_stamp.stop(true).show().animate({
							"opacity": 0.75,
							"-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=75)",
							"filter": "alpha(opacity=75)"
						}, duration);
					});


				// save reference to stamp
				$end_of_round.stamp = $incomplete_stamp;
			}
		});

		// set button text
		// the text tag for the button changes depending on whether or not this is the last round
		var button_tag = (round_id != '4') ? '|:buttons.next_round:|' : '|:buttons.next:|';

		// if we didn't pass, override button text tag
		if (!This.isPassed()) { button_tag = '|:buttons.retry:|'; }

		// now update button text
		This.settings._controller.changeButtonText(This.settings.button_name, button_tag);

		// show round end box w/ mask
		$mask.showMe();

		// save reference to summary
		$end_of_round.summary = $summary;

		// switch status-area parts
		$status.find('.in-round').hide();
		$status.find('.after-round .round-score').empty().append(This.state.points);
		$status.find('.after-round').show();
		$status.addClass('round-over');
	};

	/**
	 * Create a replacement object for the summary item
	 * @param {wombat.ict.assess.Question} q The question to use in creating the replacement object
	 * @return {Object}
	 */
	var createItemReplacement = function createItemReplacement(q) {
		var message_options, message;

		// get the right message
		message_options = wombat.assets.getText('game.categories.' + q.category.after('.') + '.summary');
		message = message_options[q.config.subtype] ? message_options[q.config.subtype] : message_options['general'];

		return {
			correct_string: q.getCorrectString(),
			choice: q.response == "visit" ? '|:game.vocab.visited:|' : '|:game.vocab.rejected:|',
			uri: q.config.uri,
			feedback: This._getDPByQuestionId(q.id).getMessage(message)
		};
	};


	// initialize
	_init_();
};

/** Extend from plugins.url.PluginRound **/
wombat.extensible.extend('wombat.ict.plugins.url.PluginRound', wombat.ict.modules.url.Round);
//# sourceMappingURL=wombat.ict.modules.url.js.map